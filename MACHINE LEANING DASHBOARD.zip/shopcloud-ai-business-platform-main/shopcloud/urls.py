"""
URL configuration for shopcloud project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.conf.urls.static import static
from . import views
from .static_serve import serve_static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('switch-language/', views.switch_language, name='switch_language'),
    path('', include('landing.urls')),
    path('auth/', include('users.urls')),
    path('dashboard/', include('dashboard.urls')),
    path('products/', include('products.urls')),
    path('billing/', include('billing.urls')),
    path('customers/', include('customers.urls')),
    path('ai-insights/', include('ai_insights.urls')),
    path('reports/', include('reports.urls')),
    path('settings/', include('settings.urls')),
]

if settings.DEBUG:
    urlpatterns += [re_path(r'^static/(?P<path>.*)$', serve_static)]
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
